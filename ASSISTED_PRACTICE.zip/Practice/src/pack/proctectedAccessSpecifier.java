
package pack;

import practices.*;

public class proctectedAccessSpecifier extends accessSpecifier {

	public static void main(String[] args) {
		accessSpecifier obj = new accessSpecifier ();   
	       obj.display3();  
	}

}
