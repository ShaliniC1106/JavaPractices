
package pack;
import practices.*;

public class publicAccessSpecifier {

	public static void main(String[] args) {
		
		accessSpecifier obj = new accessSpecifier(); 
        obj.display2();  
		
	}
}