package pack;

//using private access specifiers
class priAccess
{ 
 private void display() 
  { 
      System.out.println("You are using private access specifier"); 
  } 
} 

public class privateAccessSpecifier {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		priAccess  obj = new priAccess(); 
      //trying to access private method of another class 
      //obj.display();

	}
}