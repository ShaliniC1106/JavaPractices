package practices;

public class methodExecution {

public int addnumbers(int i,int j) {
	int r=i+j;
	return r;
}
public void area(int b,int h)
{
     System.out.println("Area of Triangle : "+(0.5*b*h));
}
public void area(int r) 
{
     System.out.println("Area of Circle : "+(3.14*r*r));
}
public static int operation(int val) {
	 
	val =val*10/100;
	return(val);

}
public static void main(String[] args) {

	methodExecution b=new methodExecution();
	
	//normal method execution
	int ans= b.addnumbers(15,11);
	System.out.println("Addition of numbers is :"+ans);
	
	
	//call by value
	int i=10;
	System.out.println("Before calling a method the value is "+ i);
	operation(i);
	System.out.println("After calling a method the value is "+i);
	
	//method overloading
     b.area(10,12);
     b.area(5);  
    
	}
}
