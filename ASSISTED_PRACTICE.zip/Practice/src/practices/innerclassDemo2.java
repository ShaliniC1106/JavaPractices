package practices;

public class innerclassDemo2 {



private String msg="Inner Classes";

void display(){  
	 class Inner{  
		 void msg(){
			 System.out.println(msg);
		 }  
 }  
 
 Inner l=new Inner();  
 l.msg();  
}  


public static void main(String[] args) {
	innerclassDemo2  ob=new innerclassDemo2 ();  
	ob.display();  
	}
}