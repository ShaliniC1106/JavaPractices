package practices;

public class arrayDemo {

public static void main(String[] args) {

//single-dimensional array
int a[]= {10,20,30,40,50};
for(int i=0;i<5;i++) {
System.out.println("Elements of array a: "+a[i]);
}


//multidimensional array
  int[][] b={ {1, 2, 3, 4}, {5, 6, 7} };
  for (int i=0;i<b.length;i++) {
     for(int j=0;j<b[i].length;j++) {
        System.out.println(b[i][j]);
      }
   }
 }
}

