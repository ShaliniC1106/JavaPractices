package practices;
public class typeCasting {

	public static void main(String[] args) {
		
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char i='C';
		System.out.println("Value of a: "+i);
		
		int a=i;
		System.out.println("Value of b: "+a);
		
		float b=i;
		System.out.println("Value of c: "+b);
		
		long c=i;
		System.out.println("Value of d: "+c);
		
		double d=i;
		System.out.println("Value of e: "+d);
		
				
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		//explicit conversion
		
		double l=15.11;
		int s=(int)l;
		System.out.println("Value of x: "+l);
		System.out.println("Value of y: "+s);
		
	}
}
