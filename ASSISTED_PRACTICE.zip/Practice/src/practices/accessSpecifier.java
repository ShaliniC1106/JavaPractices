package practices;

//default specifier
class defaultAccessSpecifier
{ 
  void display1() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 
} 

public class accessSpecifier{

	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defaultAccessSpecifier obj = new defaultAccessSpecifier(); 		  
        obj.display1(); 

	}
	//Method using for public access
	public void display2() {
		System.out.println("This is public access specifier");
	}
	
	public void display3() {
		System.out.println("This is procteted access specifier");
	}
}






