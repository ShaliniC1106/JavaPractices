package practice3;

public class ArrayRotate {
    public void rotate(int[] a, int k) {
    		if(k > a.length) 
       			k=k%a.length;
 		int[] result = new int[a.length];
 		for(int i=0; i < k; i++){
        	result[i] = a[a.length-k+i];
 		}
 		int j=0;
    	for(int i=k; i<a.length; i++){
        	result[i] = a[j];
            j++;
    	}
 		System.arraycopy( result, 0, a, 0, a.length );
    }
	public static void main(String[] args) {
		ArrayRotate r = new ArrayRotate();
        int arr[] = { 11, 12, 13, 14, 15, 16, 17 }; 
   		r.rotate(arr, 6); 
   		System.out.println("The result of the rotated array is: ");
   		for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
       	}
	}
}
