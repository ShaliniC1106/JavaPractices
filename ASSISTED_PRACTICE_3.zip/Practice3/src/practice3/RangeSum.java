package practice3;
import java.util.Scanner;

public class RangeSum{
	public static int sum(int arr[],int firstIndex, int lastIndex) {
	 int s=0;
   	 for(int i=firstIndex;i<=lastIndex;i++) {
		s=s+arr[i];
	 }
		return s;
   }	
   public static void main(String args[]){ 
	int arr[]= {7,3,42,1,3,9,5};
	int n=arr.length;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter start index: ");
    int L=sc.nextInt();
    System.out.println("Enter end index: ");
    int R=sc.nextInt();
 
    if(L>0 && R<n-1 && L<R) {
    	System.out.println("Sum of given range numbers: "+sum(arr,L,R));
    }
    else {
    	System.out.println("The range cannot exist!!");
    }
  }
}